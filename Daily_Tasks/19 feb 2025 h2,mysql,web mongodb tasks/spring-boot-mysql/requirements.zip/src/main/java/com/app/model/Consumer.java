package com.app.model;

import javax.persistence.*;

@Entity
@Table(name = "consumer")
public class Consumer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer prodId;
    private String vendorCode;
    private String prodName;
    private Integer prodCost;

    public Consumer() {}

    public Consumer(Integer prodId, String vendorCode, String prodName, Integer prodCost) {
        this.prodId = prodId;
        this.prodName = prodName;
        this.vendorCode = vendorCode;
        this.prodCost = prodCost;
    }

    // Getters and Setters
    public Integer getProdId() { return prodId; }
    public void setProdId(Integer prodId) { this.prodId = prodId; }

    public String getProdName() { return prodName; }
    public void setProdName(String prodName) { this.prodName = prodName; }

    public String getVendorCode() { return vendorCode; }
    public void setVendorCode(String vendorCode) { this.vendorCode = vendorCode; }

    public Integer getProdCost() { return prodCost; }
    public void setProdCost(Integer prodCost) { this.prodCost = prodCost; }

    @Override
    public String toString() {
        return "Product [prodId=" + prodId + ", prodName=" + prodName + ", vendorCode=" + vendorCode + ", prodCost=" + prodCost + "]";
    }
}
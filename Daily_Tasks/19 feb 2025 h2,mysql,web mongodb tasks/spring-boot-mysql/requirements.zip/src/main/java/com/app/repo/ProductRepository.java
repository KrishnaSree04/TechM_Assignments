package com.app.repo;

import com.app.model.Consumer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ProductRepository extends JpaRepository<Consumer, Integer> {

    // Define a projection interface to return selected fields
    interface MyView {
        String getVendorCode();
        String getProdName();
        Double getProdCost();
    }

    // Custom query to fetch data by vendor code using Projection
    @Query("SELECT p.vendorCode AS vendorCode, p.prodName AS prodName, p.prodCost AS prodCost FROM Product p WHERE p.vendorCode = :vendorCode")
    List<MyView> findByVendorCode(@Param("vendorCode") String vendorCode);
}

package com.app.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.app.model.Consumer;
import com.app.repo.ProductRepository;
import com.app.repo.ProductRepository.MyView;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class MyRunner implements CommandLineRunner {
    private final static Logger LOGGER = LoggerFactory.getLogger(MyRunner.class);

    @Autowired
    private ProductRepository repo;

    @Override
    public void run(String... args) throws Exception {
        LOGGER.info("Inserting consumer data...");

        repo.save(new Consumer(null, "Samsung", "AB", 100));
        repo.save(new Consumer(null, "OnePlus", "AB", 85000));
        repo.save(new Consumer(null, "Vivo", "AB", 25000));

        LOGGER.info("Data inserted successfully!");

        // Retrieve data using Projection
        List<MyView> consumers = repo.findByVendorCode("AB");
        for (MyView c : consumers) {
            System.out.println(c.getVendorCode() + "," + c.getProdName() + "," + c.getProdCost());
        }
    }
}
